<?php
      include("config.php");



//funcEnviaConfirmacaoBoleto(
//      	"ivinson@ivicomm.net", 
//      	"Ivinson Lima", 
//      	"100,00", 
//      	"10/2010"
//      	);


funcEnviaConfirmacaoBoleto_ver02(
      	"ivinson@ivicomm.net", 
      	"Ivinson Lima", 
      	"100,00", 
      	"10/2010"
      	);

?>