<?php
require_once("RetornoBanco.php");
require_once("RetornoFactory.php");

/* 
  Função handler a ser associada ao evento aoProcessarLinha de um objeto da classe 
*/
function linhaProcessada($self, $numLn, $vlinha) {
  if($vlinha) {
	  if($vlinha["registro"] == $self::DETALHE) {
      printf("%08d: ", $numLn);
      echo get_class($self) . ": Nosso N&uacute;mero <b>".$vlinha['nosso_numero']."</b> ".
           "Data <b>".$vlinha["data_ocorrencia"]."</b> ". 
           "Valor <b>".$vlinha["valor"]."</b><br/>\n";
    }
  } else echo "Tipo da linha n&atilde;o identificado<br/>\n";
}

//--------------------------------------INÍCIO DA EXECUÇÃO DO CÓDIGO-----------------------------------------------------
  $fileName = "CN19124A.RET"; //avivafinancas
  //$fileName = "CN22124A.RET"; //itau
  $cnab400 = RetornoFactory::getRetorno($fileName, "linhaProcessada");
  $retorno = new RetornoBanco($cnab400);
  $retorno->processar();

?>
