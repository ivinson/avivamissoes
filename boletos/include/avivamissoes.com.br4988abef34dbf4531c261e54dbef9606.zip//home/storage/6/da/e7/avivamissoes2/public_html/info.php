

<?php

phpinfo(); 

?> 

