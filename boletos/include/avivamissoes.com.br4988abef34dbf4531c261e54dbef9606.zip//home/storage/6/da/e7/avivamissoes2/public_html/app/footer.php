

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->



    <!-- ORIGINAL  -->
    <script src="js/jquery.js"></script>
    <!-- ADAPTACAOES -->
    <script src="http://malsup.github.com/min/jquery.form.min.js"></script>
    <script src="js/jquery-ui.1.10.2.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src="./js/plugins/chosen/chosen.jquery.js" type="text/javascript"></script>
    <script src="./js/jquery.maskMoney.min.js" type="text/javascript"></script>

    <link rel="stylesheet" href="css/jquery.printpage.css" type="text/css" media="screen" />
    <script src="./js/jquery.printpage.js"></script>

    <script src="./js/jquery.maskedinput.js" type="text/javascript"></script>
    
<!--
    <script type="text/javascript">
    var config = {
      '.chosen-select'           : {}
      ,'.chosen-select-no-results': {no_results_text:'Oops, nenhum nome...'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
    </script>

-->

    <script type="text/javascript" src="./js/jquery.dataTables.min.js"></script>
    <link href='./css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>




<script type="text/javascript">
// Read a page's GET URL variables and return them as an associative array.
function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}


</script>



</body>

</html>