

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->



    <!-- ORIGINAL  -->
    <script src="js/jquery.js"></script>
    <!-- ADAPTACAOES -->
    <script src="http://malsup.github.com/min/jquery.form.min.js"></script>
    <script src="js/jquery-ui.1.10.2.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>



        <!-- Morris Charts JavaScript 
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>
-->

   <!-- Flot Charts JavaScript -->
    <!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
   
<!--
    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/flot-data.js"></script>
 -->
    
<!--
    <script src="./js/plugins/chosen/chosen.jquery.js" type="text/javascript"></script>
    <script type="text/javascript">
    var config = {
      '.chosen-select'           : {}
      ,'.chosen-select-no-results': {no_results_text:'Oops, nenhum nome...'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
    </script>

-->




</body>

</html>









